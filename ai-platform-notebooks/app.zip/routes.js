const mysql = require("promise-mysql")
const uuid = require("uuid")

var appRouter = function (app) {

    async function get_db() {
        return await mysql.createPool({
            user: process.env.DB_USER,
            password: process.env.DB_PASSWORD,
            database: process.env.DB_NAME,
            host: process.env.DB_HOST,
        });
    }

    app.get("/ca-get-messages", async (req, res) => {
        const db = await get_db();
        const setup = await db.query("CREATE TABLE IF NOT EXISTS messages (id VARCHAR(255) NOT NULL, message TEXT,last_edited DATETIME,PRIMARY KEY(id))");
        const messages = await db.query("SELECT * FROM messages")
        db.end()

        return res.status(200).send(messages)
    });

    app.post("/ca-post-message", async (req, res) => {
        const db = await get_db();
        const newMessageId = uuid.v4()
        const messageContent = req.body.message

        try {
            const queryStatement = mysql.format("INSERT INTO messages (id, message, last_edited) VALUES (?, ?, CURRENT_TIMESTAMP)", [
                newMessageId,
                messageContent
            ])

            await db.query(queryStatement)
            db.end()
            return res.status(201).send({
                messageId: newMessageId
            })
        } catch (error) {
            db.end()
            return res.status(500).send()
        }
    });

    app.patch("/ca-patch-message", async (req, res) => {
        const db = await get_db();
        const updatingMessageId = req.query.messageId
        const messageContent = req.body.message

        try {
            const queryStatement = mysql.format(
                "UPDATE messages SET message=?, last_edited=CURRENT_TIMESTAMP WHERE id=?",
                [messageContent, updatingMessageId]
            )

            const resp = await db.query(queryStatement)
            db.end()

            // Return a 404 if no rows were changed
            if (resp.changedRows === 0) {
                return res.status(404).send()
            }

            return res.status(200).send()
        } catch (error) {
            db.end()
            return res.status(500).send()
        }
    });

    app.delete("/ca-delete-message", async (req, res) => {
        const db = await get_db();
        const deletingMessageId = req.query.messageId
        if (!deletingMessageId) {
            return res.status(400).send()
        }

        try {
            const queryStatement = mysql.format("DELETE FROM messages WHERE id=?", [
                deletingMessageId,
            ])
            const resp = await db.query(queryStatement)
            db.end()

            // Return 404 if no rows were changed
            if (resp.affectedRows === 0) {
                return res.status(404).send()
            }

            return res.status(200).send()
        } catch (error) {
            db.end()
            return res.status(500).send()
        }
    });
}

module.exports = appRouter;